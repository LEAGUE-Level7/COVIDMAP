import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import javax.swing.ImageIcon; 
import com.google.gson.annotations.Expose; 
import com.google.gson.annotations.SerializedName; 
import java.text.DecimalFormat; 
import static javax.swing.JOptionPane.*; 
import javax.imageio.ImageIO; 
import java.net.URL; 
import javax.net.ssl.HttpsURLConnection; 
import javax.json.Json; 
import javax.json.JsonObject; 
import javax.json.JsonReader; 
import java.net.MalformedURLException; 
import java.net.ProtocolException; 
import java.io.IOException; 
import java.util.List; 
import com.google.gson.annotations.Expose; 
import com.google.gson.annotations.SerializedName; 
import java.net.*; 
import java.io.*; 
import java.net.URL; 
import javax.net.ssl.HttpsURLConnection; 
import javax.json.Json; 
import javax.json.JsonObject; 
import javax.json.JsonReader; 
import java.net.MalformedURLException; 
import java.net.ProtocolException; 
import java.io.IOException; 
import com.google.gson.annotations.Expose; 
import com.google.gson.annotations.SerializedName; 
import java.net.URL; 
import javax.net.ssl.HttpsURLConnection; 
import javax.json.Json; 
import javax.json.JsonObject; 
import javax.json.JsonArray; 
import javax.json.JsonReader; 
import java.net.MalformedURLException; 
import java.net.ProtocolException; 
import java.io.IOException; 
import java.util.*; 

import com.google.gson.*; 
import com.google.gson.stream.*; 
import com.google.gson.reflect.*; 
import com.google.gson.internal.*; 
import com.google.gson.internal.reflect.*; 
import com.google.gson.internal.bind.*; 
import com.google.gson.internal.bind.util.*; 
import com.google.gson.annotations.*; 
import javax.json.*; 
import javax.json.spi.*; 
import javax.json.stream.*; 
import org.glassfish.json.*; 
import org.glassfish.json.api.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Display extends PApplet {



public class MainDisplay {
  News news;
  NewsDatum newsInfo;
  PImage californiaMap;
  final int WIDTH = 1100;
  final int HEIGHT = 700;
  int[] xValues = {456, 113, 167, 388, 84, 243, 588, 568, 527, 497, 250, 
    156, 419, 451, 371, 321, 470, 385, 608, 553, 597, 463, 360, 423, 385, 
    217, 314, 123, 592, 576, 233, 561, 541, 308, 488, 335, 103, 538, 599, 
    525, 303, 456, 312, 177, 578, 541, 121, 510, 413, 231};
  int[] yValues = {318, 372, 292, 298, 243, 236, 171, 217, 381, 316, 417, 
    155, 223, 218, 196, 246, 250, 341, 112, 212, 157, 178, 145, 322, 250, 
    120, 207, 208, 141, 198, 301, 159, 270, 118, 211, 290, 141, 199, 168, 
    298, 162, 280, 344, 226, 134, 239, 97, 235, 163, 178};

  Button feverButton = new Button("Fever/chills", 860, 450, 90, 30);
  Button coughButton = new Button("Cough", 860, 490, 90, 30);
  Button fatigueButton = new Button("Fatigue", 860, 530, 90, 30);
  Button breathingButton = new Button("Short breath", 860, 570, 90, 30);
  Button headacheButton = new Button("Headache", 860, 610, 90, 30);
  Button lossOfTasteButton = new Button("Loss of taste", 860, 650, 90, 30);
  Button soreThroatButton = new Button("Sore throat", 980, 450, 90, 30);
  Button congestionButton = new Button("Congestion", 980, 490, 90, 30);
  Button runnyNoseButton = new Button("Runny nose", 980, 530, 90, 30);
  Button nauseaButton = new Button("Nausea", 980, 570, 90, 30);
  Button vomitingButton = new Button("Vomiting", 980, 610, 90, 30);
  Button diarrheaButton = new Button("Diarrhea", 980, 650, 90, 30);
  
  Button stAnthonyButton = new Button("St. Anthony's of Padua Parking Lot", 100, 70, 240, 30);
  Button tubmanChavezButton = new Button("Tubman-Chavez Community Center", 100, 110, 240, 30);
  Button aquaticaButton = new Button("Aquatica San Diego", 100, 150, 240, 30);
  Button sycuanButton = new Button("Sycuan Market", 100, 190, 240, 30);
  Button marVistaButton = new Button("Mar Vista High School", 100, 230, 240, 30);
  Button northCoastalButton = new Button("North Coastal Live Well Health Center", 100, 270, 240, 30);
  Button lgbtButton = new Button("The San Diego LGBT Community Center", 100, 310, 240, 30);
  Button euclidButton = new Button("Euclid Health Center", 100, 350, 240, 30);
  
  Button sdStateButton = new Button("San Diego State University Parking Lot 17B", 400, 70, 240, 30);
  Button usdLotButton = new Button("University of San Diego (USD) Parking Lot", 400, 110, 240, 30);
  Button searsButton = new Button("Old Sears Building", 400, 150, 240, 30);
  Button assessorRecorderButton = new Button("Assessor Recorder County Clerk Building", 400, 190, 240, 30);
  Button escondidoTheaterButton = new Button("California Center for the Arts, Escondido Center Theater", 400, 230, 240, 30);
  Button kimballButton = new Button("Kimball Senior Center", 400, 270, 240, 30);
  Button sanYsidroButton = new Button("San Ysidro Civic Center", 400, 310, 240, 30);
  Button miraMesaButton = new Button("Mira Mesa Senior Center", 400, 350, 240, 30);
  

  public void testingLocations() {
    float fontSize = 13; 
    stAnthonyButton.display(232, 232, 232, fontSize);
    tubmanChavezButton.display(232, 232, 232, fontSize);
    aquaticaButton.display(232, 232, 232, fontSize);
    sycuanButton.display(232, 232, 232, fontSize);
    marVistaButton.display(232, 232, 232, fontSize);
    northCoastalButton.display(232, 232, 232, fontSize);
    lgbtButton.display(232, 232, 232, fontSize);
    euclidButton.display(232, 232, 232, fontSize);
    
    sdStateButton.display(232, 232, 232, 12);
    usdLotButton.display(232, 232, 232, fontSize);
    searsButton.display(232, 232, 232, fontSize);
    assessorRecorderButton.display(232, 232, 232, fontSize);
    escondidoTheaterButton.display(232, 232, 232, 9.8f);
    kimballButton.display(232, 232, 232, fontSize);
    sanYsidroButton.display(232, 232, 232, fontSize);
    miraMesaButton.display(232, 232, 232, fontSize);
  }
  

  public void grid() {
    strokeWeight(4);
    stroke(0);
    line(0, HEIGHT*2/3, WIDTH*3/4, HEIGHT*2/3);
    line(WIDTH*3/4, 300, WIDTH, 300);//300 //50
    line(WIDTH*3/4, 400, WIDTH, 400);
    line(WIDTH*3/4, 0, WIDTH*3/4, HEIGHT);
    strokeWeight(1);
  }

  public void headers() {
    textSize(25);
    fill(179, 0, 0);
    text("Symptoms", 900, 435);
    text("Regulations", 890, 335);
    text("News Updates", 880, 35);
    text("Graph", 375, 500);
  }
  public void baseText() {
    feverButton = new Button("Fever/Chills", 850, 450, 100, 30);
    coughButton = new Button("Cough", 850, 490, 100, 30);
    fatigueButton = new Button("Fatigue", 850, 530, 100, 30);
    breathingButton = new Button("Short of breath", 850, 570, 100, 30);
    headacheButton = new Button("Headache", 850, 610, 100, 30);
    lossOfTasteButton = new Button("Loss of taste", 850, 650, 100, 30);

    soreThroatButton = new Button("Sore throat", 980, 450, 100, 30);
    congestionButton = new Button("Congestion", 980, 490, 100, 30);
    runnyNoseButton = new Button("Runny nose", 980, 530, 100, 30);
    nauseaButton = new Button("Nausea", 980, 570, 100, 30);
    vomitingButton = new Button("Vomiting", 980, 610, 100, 30);
    diarrheaButton = new Button("Diarrhea", 980, 650, 100, 30);
    feverButton.display(232, 232, 232, 14.5f);
    coughButton.display(232, 232, 232, 14.5f);
    fatigueButton.display(232, 232, 232, 14.5f);
    breathingButton.display(232, 232, 232, 14);
    headacheButton.display(232, 232, 232, 14.5f);
    lossOfTasteButton.display(232, 232, 232, 14.5f);
    soreThroatButton.display(232, 232, 232, 14.5f);
    congestionButton.display(232, 232, 232, 14.5f);
    runnyNoseButton.display(232, 232, 232, 14.5f);
    nauseaButton.display(232, 232, 232, 14.5f);
    vomitingButton.display(232, 232, 232, 14.5f);
    diarrheaButton.display(232, 232, 232, 14.5f);

    String rules = "Wear a mask. Wash your hands. Keep your distance!";

    textSize(9);
    fill(170, 170, 100);
    text("CLICK for more info", WIDTH*3/4 + 160, 395);
    textSize(14.5f);
    fill(0, 0, 0);
    text(rules.substring(0, 29), 830, 345, WIDTH, 700);
    text(rules.substring(30), 830, 365, WIDTH, 700);
  }

  public void usMap() {
    californiaMap = loadImage("unitedStatesMap.png");
    image(californiaMap, 40, 60, 600, 400);
  }

  public void circles(int[] data, int r, int g, int b) {
    noStroke();
    for (int i = 0; i < 50; i++) {
      fill(r, g, b, 150);
      ellipse(xValues[i], yValues[i], (float)(Math.sqrt(data[i])), (float)(Math.sqrt(data[i])));
    }
  }
  
  public void graph(int[] pI, int scale, int type) {
    Graph graph = new Graph();
    graph.initialize(pI);
    graph.organizeData(pI);
    if (type == 0){
      graph.displayBar(scale);
    } else if (type == 1) {
      graph.displayTop5(scale);
    }
    textAlign(0);
    String[] fontList = PFont.list();
    PFont font = createFont(fontList[168], 32);
    textFont(font);
  }

  public void showNews() {//51 //300 //83 spacing
    strokeWeight(1);
    stroke(0);
    line(WIDTH*3/4, 51, WIDTH, 51);
    line(WIDTH*3/4, 134, WIDTH, 134);//300 //50
    line(WIDTH*3/4, 217, WIDTH, 217);
    for (int i = 0; i < 3; i++) {
      try {
        newsInfo.getArticles().get(i);
      }
      catch(Exception e) {
        continue;
      }
      String title = newsInfo.getArticles().get(i).getTitle();
      String description = newsInfo.getArticles().get(i).getDescription();
      String author = newsInfo.getArticles().get(i).getAuthor();
      if (author == null){
        author = "Not specified";
      }
      String publishedAt = newsInfo.getArticles().get(i).getPublishedAt();
      title = title.substring(0, 45) + "...";
      textSize(10);
      fill(0, 0, 255);
      text(title, 1 + WIDTH*3/4 + 3, 56 + (83*i), WIDTH, 65 + (83*i));
      fill(50, 50, 50);
      textSize(9);
      String firstDescription;
      try {
        firstDescription = description.substring(0, 55);
      }
      catch(Exception e) {
        firstDescription = description + "...";
      }
      String secondDescription;
      try {
        secondDescription = description.substring(55, 110) + "...";
      }
      catch(Exception e) {
        secondDescription = "";
      }
      text(firstDescription, 1 + WIDTH*3/4 + 3, 70 + (83*i), WIDTH, 80 + (83*i));
      text(secondDescription, 1 + WIDTH*3/4 + 3, 80 + (83*i), WIDTH, 90 + (83*i));
      publishedAt = "Date: " + publishedAt;
      text(publishedAt, 1 + WIDTH*3/4 + 3, 97 + (83*i), WIDTH, 107 + (83*i));
      author = "Author: " + author;
      text(author, 1 + WIDTH*3/4 + 3, 110 + (83*i), WIDTH, 125 + (83*i));
      if (!title.equals("")) {
        textSize(9);
        fill(170, 170, 100);
        text("CLICK for more info", 1 + WIDTH*3/4 + 160, 120 + (83*i), WIDTH, 130 + (83*i));
      }
    }
    strokeWeight(1);
  }
  
  public NewsDatum getCurrentNews() {
    news = new News();
    if (newsInfo == null) {
      newsInfo = news.fetchTopNews();
    }
    return newsInfo;
  }
}
public class ArticleDatum{
  @SerializedName("title")
    @Expose
    private String title;
  @SerializedName("description")
    @Expose
    private String description;
  @SerializedName("author")
    @Expose
    private String author;
  @SerializedName("url")
    @Expose
    private String url;
  @SerializedName("publishedAt")
    @Expose
    private String publishedAt;
    
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }
  
  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }
  
  public String getAuthor() {
    return author;
  }

  public void setAuthor(String author) {
    this.author = author;
  }
  
  public String getURL() {
    return url;
  }

  public void setURL(String url) {
    this.url = url;
  }
  
  public String getPublishedAt() {
    return publishedAt;
  }

  public void setPublishedAt(String publishedAt) {
    this.publishedAt = publishedAt;
  }
}
class Button {
  String label;
  float x;    // top left corner x position
  float y;    // top left corner y position
  float w;    // width of button
  float h;    // height of button

  Button(String labelB, float xpos, float ypos, float widthB, float heightB) {
    label = labelB;
    x = xpos;
    y = ypos;
    w = widthB;
    h = heightB;
  }

  public void display(int r, int g, int b, float fontSize) {
    pushMatrix();
    textSize(fontSize);
    fill(r, g, b, 150);
    strokeWeight(1);
    stroke(141);
    rect(x, y, w, h, 10);
    textAlign(CENTER, CENTER);
    fill(0);
    text(label, x + (w / 2), y + (h / 2) - 3);
    popMatrix();
    textAlign(0);
  }

  public boolean mouseIsOver() {
    if (mouseX > x && mouseX < (x + w) && mouseY > y && mouseY < (y + h)) {
      return true;
    }
    return false;
  }
}



public class Datum {

  @SerializedName("date")
    @Expose
    private Integer date;
  @SerializedName("state")
    @Expose
    private String state;
  @SerializedName("positive")
    @Expose
    private Integer positive;
  @SerializedName("negative")
    @Expose
    private Integer negative;
  @SerializedName("pending")
    @Expose
    private Object pending;
  @SerializedName("hospitalizedCurrently")
    @Expose
    private Integer hospitalizedCurrently;
  @SerializedName("hospitalizedCumulative")
    @Expose
    private Object hospitalizedCumulative;
  @SerializedName("inIcuCurrently")
    @Expose
    private Integer inIcuCurrently;
  @SerializedName("inIcuCumulative")
    @Expose
    private Object inIcuCumulative;
  @SerializedName("onVentilatorCurrently")
    @Expose
    private Object onVentilatorCurrently;
  @SerializedName("onVentilatorCumulative")
    @Expose
    private Object onVentilatorCumulative;
  @SerializedName("recovered")
    @Expose
    private Object recovered;
  @SerializedName("dataQualityGrade")
    @Expose
    private String dataQualityGrade;
  @SerializedName("lastUpdateEt")
    @Expose
    private String lastUpdateEt;
  @SerializedName("dateModified")
    @Expose
    private String dateModified;
  @SerializedName("checkTimeEt")
    @Expose
    private String checkTimeEt;
  @SerializedName("death")
    @Expose
    private Integer death;
  @SerializedName("hospitalized")
    @Expose
    private Object hospitalized;
  @SerializedName("dateChecked")
    @Expose
    private String dateChecked;
  @SerializedName("totalTestsViral")
    @Expose
    private Integer totalTestsViral;
  @SerializedName("positiveTestsViral")
    @Expose
    private Object positiveTestsViral;
  @SerializedName("negativeTestsViral")
    @Expose
    private Object negativeTestsViral;
  @SerializedName("positiveCasesViral")
    @Expose
    private Integer positiveCasesViral;
  @SerializedName("deathConfirmed")
    @Expose
    private Object deathConfirmed;
  @SerializedName("deathProbable")
    @Expose
    private Object deathProbable;
  @SerializedName("fips")
    @Expose
    private String fips;
  @SerializedName("positiveIncrease")
    @Expose
    private Integer positiveIncrease;
  @SerializedName("negativeIncrease")
    @Expose
    private Integer negativeIncrease;
  @SerializedName("total")
    @Expose
    private Integer total;
  @SerializedName("totalTestResults")
    @Expose
    private Integer totalTestResults;
  @SerializedName("totalTestResultsIncrease")
    @Expose
    private Integer totalTestResultsIncrease;
  @SerializedName("posNeg")
    @Expose
    private Integer posNeg;
  @SerializedName("deathIncrease")
    @Expose
    private Integer deathIncrease;
  @SerializedName("hospitalizedIncrease")
    @Expose
    private Integer hospitalizedIncrease;
  @SerializedName("hash")
    @Expose
    private String hash;
  @SerializedName("commercialScore")
    @Expose
    private Integer commercialScore;
  @SerializedName("negativeRegularScore")
    @Expose
    private Integer negativeRegularScore;
  @SerializedName("negativeScore")
    @Expose
    private Integer negativeScore;
  @SerializedName("positiveScore")
    @Expose
    private Integer positiveScore;
  @SerializedName("score")
    @Expose
    private Integer score;
  @SerializedName("grade")
    @Expose
    private String grade;

  public String toString() {
    String stateInfo = "{";
    stateInfo += "\"date\": " + date + ",";
    stateInfo += "\"positive\": " + positive + ",";
    stateInfo += "\"negative\": " + negative + ",";
    stateInfo += "\"pending\": " + pending + ",";
    stateInfo += "\"hospitalizedCurrently\": " + hospitalizedCurrently + ",";
    stateInfo += "\"hospitalizedCumulative\": " + hospitalizedCurrently + ",";
    stateInfo += "\"inIcuCurrently\": " + inIcuCurrently + ",";
    stateInfo += "\"inIcuCumulative\": " + inIcuCumulative + ",";
    stateInfo += "\"onVentilatorCurrently\": " + onVentilatorCurrently + ",";
    stateInfo += "\"onVentilatorCumulative\": " + onVentilatorCumulative + ",";
    stateInfo += "\"recovered\": " + recovered + ",";
    stateInfo += "\"dataQualityGrade\": " + dataQualityGrade + ","; 
    stateInfo += "\"lastUpdateEt\": " + lastUpdateEt + ",";
    stateInfo += "\"dateModified\": " + dateModified + ",";
    stateInfo += "\"checkTimeEt\": " + checkTimeEt + ",";
    stateInfo += "\"death\": " + death + ",";
    stateInfo += "\"hospitalized\": " + hospitalized + ",";
    stateInfo += "\"dateChecked\": " + dateChecked + ",";
    stateInfo += "\"totalTestsViral\": " + totalTestsViral + ",";
    stateInfo += "\"positiveTestsViral\": " + positiveTestsViral + ",";
    stateInfo += "\"negativeTestsViral\": " + negativeTestsViral + ",";
    stateInfo += "\"positiveCasesViral\": " + positiveCasesViral + ",";
    stateInfo += "\"deathConfirmed\": " + deathConfirmed + ",";
    stateInfo += "\"deathProbable\": " + deathProbable + ",";
    stateInfo += "\"fips\": " + fips + ",";
    stateInfo += "\"positiveIncrease\": " + positiveIncrease + ",";
    stateInfo += "\"negativeIncrease\": " + negativeIncrease + ",";
    stateInfo += "\"total\": " + total + ",";
    stateInfo += "\"totalTestResults\": " + totalTestResults + ",";
    stateInfo += "\"totalTestResultsIncrease\": " + totalTestResultsIncrease + ",";
    stateInfo += "\"posNeg\": " + posNeg + ",";
    stateInfo += "\"deathIncrease\": " + deathIncrease + ",";
    stateInfo += "\"hospitalizedIncrease\": " + hospitalizedIncrease + ",";
    stateInfo += "\"hash\": " + hash + ",";
    stateInfo += "\"commercialScore\": " + commercialScore + ",";
    stateInfo += "\"negativeRegularScore\": " + negativeRegularScore + ",";
    stateInfo += "\"negativeScore\": " + negativeScore + ",";
    stateInfo += "\"positiveScore\": " + positiveScore + ",";
    stateInfo += "\"score\": " + score + ",";
    stateInfo += "\"grade\": " + grade;
    stateInfo += "}";
    return stateInfo;
  }

  public Integer getDate() {
    return date;
  }

  public void setDate(Integer date) {
    this.date = date;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public Integer getPositive() {
    System.out.println("pk is bae");
    return positive;
  }

  public void setPositive(Integer positive) {
    this.positive = positive;
  }

  public Integer getNegative() {
    return negative;
  }

  public void setNegative(Integer negative) {
    this.negative = negative;
  }

  public Object getPending() {
    return pending;
  }

  public void setPending(Object pending) {
    this.pending = pending;
  }

  public Integer getHospitalizedCurrently() {
    return hospitalizedCurrently;
  }

  public void setHospitalizedCurrently(Integer hospitalizedCurrently) {
    this.hospitalizedCurrently = hospitalizedCurrently;
  }

  public Object getHospitalizedCumulative() {
    return hospitalizedCumulative;
  }

  public void setHospitalizedCumulative(Object hospitalizedCumulative) {
    this.hospitalizedCumulative = hospitalizedCumulative;
  }

  public Integer getInIcuCurrently() {
    return inIcuCurrently;
  }

  public void setInIcuCurrently(Integer inIcuCurrently) {
    this.inIcuCurrently = inIcuCurrently;
  }

  public Object getInIcuCumulative() {
    return inIcuCumulative;
  }

  public void setInIcuCumulative(Object inIcuCumulative) {
    this.inIcuCumulative = inIcuCumulative;
  }

  public Object getOnVentilatorCurrently() {
    return onVentilatorCurrently;
  }

  public void setOnVentilatorCurrently(Object onVentilatorCurrently) {
    this.onVentilatorCurrently = onVentilatorCurrently;
  }

  public Object getOnVentilatorCumulative() {
    return onVentilatorCumulative;
  }

  public void setOnVentilatorCumulative(Object onVentilatorCumulative) {
    this.onVentilatorCumulative = onVentilatorCumulative;
  }

  public Object getRecovered() {
    return recovered;
  }

  public void setRecovered(Object recovered) {
    this.recovered = recovered;
  }

  public String getDataQualityGrade() {
    return dataQualityGrade;
  }

  public void setDataQualityGrade(String dataQualityGrade) {
    this.dataQualityGrade = dataQualityGrade;
  }

  public String getLastUpdateEt() {
    return lastUpdateEt;
  }

  public void setLastUpdateEt(String lastUpdateEt) {
    this.lastUpdateEt = lastUpdateEt;
  }

  public String getDateModified() {
    return dateModified;
  }

  public void setDateModified(String dateModified) {
    this.dateModified = dateModified;
  }

  public String getCheckTimeEt() {
    return checkTimeEt;
  }

  public void setCheckTimeEt(String checkTimeEt) {
    this.checkTimeEt = checkTimeEt;
  }

  public Integer getDeath() {
    return death;
  }

  public void setDeath(Integer death) {
    this.death = death;
  }

  public Object getHospitalized() {
    return hospitalized;
  }

  public void setHospitalized(Object hospitalized) {
    this.hospitalized = hospitalized;
  }

  public String getDateChecked() {
    return dateChecked;
  }

  public void setDateChecked(String dateChecked) {
    this.dateChecked = dateChecked;
  }

  public Integer getTotalTestsViral() {
    return totalTestsViral;
  }

  public void setTotalTestsViral(Integer totalTestsViral) {
    this.totalTestsViral = totalTestsViral;
  }

  public Object getPositiveTestsViral() {
    return positiveTestsViral;
  }

  public void setPositiveTestsViral(Object positiveTestsViral) {
    this.positiveTestsViral = positiveTestsViral;
  }

  public Object getNegativeTestsViral() {
    return negativeTestsViral;
  }

  public void setNegativeTestsViral(Object negativeTestsViral) {
    this.negativeTestsViral = negativeTestsViral;
  }

  public Integer getPositiveCasesViral() {
    return positiveCasesViral;
  }

  public void setPositiveCasesViral(Integer positiveCasesViral) {
    this.positiveCasesViral = positiveCasesViral;
  }

  public Object getDeathConfirmed() {
    return deathConfirmed;
  }

  public void setDeathConfirmed(Object deathConfirmed) {
    this.deathConfirmed = deathConfirmed;
  }

  public Object getDeathProbable() {
    return deathProbable;
  }

  public void setDeathProbable(Object deathProbable) {
    this.deathProbable = deathProbable;
  }

  public String getFips() {
    return fips;
  }

  public void setFips(String fips) {
    this.fips = fips;
  }

  public Integer getPositiveIncrease() {
    return positiveIncrease;
  }

  public void setPositiveIncrease(Integer positiveIncrease) {
    this.positiveIncrease = positiveIncrease;
  }

  public Integer getNegativeIncrease() {
    return negativeIncrease;
  }

  public void setNegativeIncrease(Integer negativeIncrease) {
    this.negativeIncrease = negativeIncrease;
  }

  public Integer getTotal() {
    return total;
  }

  public void setTotal(Integer total) {
    this.total = total;
  }

  public Integer getTotalTestResults() {
    return totalTestResults;
  }

  public void setTotalTestResults(Integer totalTestResults) {
    this.totalTestResults = totalTestResults;
  }

  public Integer getTotalTestResultsIncrease() {
    return totalTestResultsIncrease;
  }

  public void setTotalTestResultsIncrease(Integer totalTestResultsIncrease) {
    this.totalTestResultsIncrease = totalTestResultsIncrease;
  }

  public Integer getPosNeg() {
    return posNeg;
  }

  public void setPosNeg(Integer posNeg) {
    this.posNeg = posNeg;
  }

  public Integer getDeathIncrease() {
    return deathIncrease;
  }

  public void setDeathIncrease(Integer deathIncrease) {
    this.deathIncrease = deathIncrease;
  }

  public Integer getHospitalizedIncrease() {
    return hospitalizedIncrease;
  }

  public void setHospitalizedIncrease(Integer hospitalizedIncrease) {
    this.hospitalizedIncrease = hospitalizedIncrease;
  }

  public String getHash() {
    return hash;
  }

  public void setHash(String hash) {
    this.hash = hash;
  }

  public Integer getCommercialScore() {
    return commercialScore;
  }

  public void setCommercialScore(Integer commercialScore) {
    this.commercialScore = commercialScore;
  }

  public Integer getNegativeRegularScore() {
    return negativeRegularScore;
  }

  public void setNegativeRegularScore(Integer negativeRegularScore) {
    this.negativeRegularScore = negativeRegularScore;
  }

  public Integer getNegativeScore() {
    return negativeScore;
  }

  public void setNegativeScore(Integer negativeScore) {
    this.negativeScore = negativeScore;
  }

  public Integer getPositiveScore() {
    return positiveScore;
  }

  public void setPositiveScore(Integer positiveScore) {
    this.positiveScore = positiveScore;
  }

  public Integer getScore() {
    return score;
  }

  public void setScore(Integer score) {
    this.score = score;
  }

  public String getGrade() {
    return grade;
  }

  public void setGrade(String grade) {
    this.grade = grade;
  }
}


public class Graph {
  Map map = new Map();
  int[] unsortedData = new int[50];
  String[] states = new String[50];
  int index = 0;
  int highest = 1;
  int totalSum = 1;
  int rectY = 0;
  int rectHeight = 0;
  PFont mono;
  int sumTop5 = 1;
  int[] top5index = new int[5];
  float[] top5scale = new float[5];
  int[][] colors = {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0}};

  public void initialize(int[] pI) {
    this.unsortedData = pI;
    this.states = map.states;
    mono = loadFont("Consolas-48.vlw");
  }

  public void displayBar(int number) {
    strokeWeight(5);
    fill(0, 0, 0);
    line(5, 700, 815, 650);
    textAlign(CENTER);
    textFont(mono, 12);
    float scale = 150.0f/highest;
    for (int i = 0; i < 50; i++) {
      fill(0, 0, 0);
      text(states[i].toUpperCase(), 12 + 16.25f*i, 670);
      switch (number) {
        case 0:
          fill(255, 0, 0);
          break;
        case 1:
          fill(0, 0, 255);
          break;
        case 2:
          fill(0, 200, 0);
          break;
        case 3:
          fill(200, 200, 0);
          break;
      }
        rect((10 + (16.25f*i)), (650 - (unsortedData[i]*scale)), 5, (unsortedData[i]*scale));
        if (i == index) {
          rectY = (int)(650 - (unsortedData[i]*scale));
          rectHeight = (int)(unsortedData[i]*scale);
        }
    }
    //y axis
    textFont(mono, 12);
    fill(0, 0, 0);
    text(unsortedData[index] + " -", 25, rectY);
    text((unsortedData[index]/2) + " -", 25, (rectY + rectHeight/2));
  }
  
  public void displayTop5(int number) {
    //ellipse(150, 600, 160, 160);
    String[] fontList = PFont.list();
    PFont font = createFont(fontList[168], 16);
    textFont(font);
    fill(0, 0, 0);
    text("Top 5 States", 60, 500);
    text("Percentage of Total", 540, 500);
    //right display
    textFont(mono, 15);
    DecimalFormat df = new DecimalFormat("##.##");
    text(states[top5index[0]].toUpperCase() + " - " + df.format((((float)unsortedData[top5index[0]])/totalSum)*100) + "% --> " + unsortedData[top5index[0]] + "/" + totalSum, 500, 535);
    text(states[top5index[1]].toUpperCase() + " - " + df.format((((float)unsortedData[top5index[1]])/totalSum)*100) + "% --> " + unsortedData[top5index[1]] + "/" + totalSum, 500, 570);
    text(states[top5index[2]].toUpperCase() + " - " + df.format((((float)unsortedData[top5index[2]])/totalSum)*100) + "% --> " + unsortedData[top5index[2]] + "/" + totalSum, 500, 605);
    text(states[top5index[3]].toUpperCase() + " - " + df.format((((float)unsortedData[top5index[3]])/totalSum)*100) + "% --> " + unsortedData[top5index[3]] + "/" + totalSum, 500, 640);
    text(states[top5index[4]].toUpperCase() + " - " + df.format((((float)unsortedData[top5index[4]])/totalSum)*100) + "% --> " + unsortedData[top5index[4]] + "/" + totalSum, 500, 675);
    //left graph
    pickColors(number);
    //highest
    fill(colors[0][0], colors[0][1], colors[0][2]);
    stroke(colors[0][0], colors[0][1], colors[0][2]);
    rect(215, 510, 15, 15);
    noStroke();
    arc(100f, 600f, 160f, 160f, 0, (2*PI*top5scale[0]), PIE);
    //2nd highest
    fill(colors[1][0], colors[1][1], colors[1][2]);
    stroke(colors[0][0], colors[0][1], colors[0][2]);
    rect(215, 550, 15, 15);
    noStroke();
    arc(100f, 600f, 160f, 160f, (2*PI*top5scale[0]), (2*PI*top5scale[1] + 2*PI*top5scale[0]), PIE);
    //3rd highest
    fill(colors[2][0], colors[2][1], colors[2][2]);
    stroke(colors[0][0], colors[0][1], colors[0][2]);
    rect(215, 590, 15, 15);
    noStroke();
    arc(100f, 600f, 160f, 160f, (2*PI*top5scale[1] + 2*PI*top5scale[0]), (2*PI*top5scale[0] + 2*PI*top5scale[1] + 2*PI*top5scale[2]), PIE);
    //4th highest
    fill(colors[3][0], colors[3][1], colors[3][2]);
    stroke(colors[0][0], colors[0][1], colors[0][2]);
    rect(215, 630, 15, 15);
    noStroke();
    arc(100f, 600f, 160f, 160f, (2*PI*top5scale[0] + 2*PI*top5scale[1] + 2*PI*top5scale[2]), (2*PI*top5scale[0] + 2*PI*top5scale[1] + 2*PI*top5scale[2] + 2*PI*top5scale[3]), PIE);
    //5th highest
    fill(colors[4][0], colors[4][1], colors[4][2]);
    stroke(colors[0][0], colors[0][1], colors[0][2]);
    rect(215, 670, 15, 15);
    noStroke();
    arc(100f, 600f, 160f, 160f, (2*PI*top5scale[0] + 2*PI*top5scale[1] + 2*PI*top5scale[2] + 2*PI*top5scale[3]), (2*PI*top5scale[0] + 2*PI*top5scale[1] + 2*PI*top5scale[2] + 2*PI*top5scale[3] + 2*PI*top5scale[4]), PIE);
    //text
    fill(0, 0, 0);
    textFont(mono, 15);
    text(states[top5index[0]].toUpperCase() + " - " + unsortedData[top5index[0]], 245, 523);
    text(states[top5index[1]].toUpperCase() + " - " + unsortedData[top5index[1]], 245, 563);
    text(states[top5index[2]].toUpperCase() + " - " + unsortedData[top5index[2]], 245, 603);
    text(states[top5index[3]].toUpperCase() + " - " + unsortedData[top5index[3]], 245, 643);
    text(states[top5index[4]].toUpperCase() + " - " + unsortedData[top5index[4]], 245, 683);
  }
  
  public void pickColors(int number) {
    switch (number) {
      case 0:
        colors = new int [][]{{250, 0, 0}, {250, 25, 25}, {250, 50, 50}, {250, 75, 75}, {250, 100, 100}};
        break;
      case 1:
        colors = new int [][]{{0, 0, 250}, {30, 30, 250}, {60, 60, 250}, {90, 90, 250}, {120, 120, 250}};
        break;
      case 2:
        colors = new int [][]{{0, 200, 0}, {40, 200, 40}, {80, 200, 80}, {120, 200, 120}, {160, 200, 160}};
        break;
      case 3:
        colors = new int [][]{{250, 180, 0}, {250, 185, 50}, {250, 190, 100}, {250, 195, 150}, {250, 200, 200}};
        break;
    }
  }

  public void organizeData(int[] pI) {
    int[] temp = sort(pI);
    highest = temp[temp.length-1];
    index = search(unsortedData, highest);
    top5index[0] = index;
    for (int i = 1; i < 5; i++) {
      top5index[i] = search(unsortedData, temp[temp.length-(i+1)]);
    }
    sumTop5 = temp[temp.length-1] + temp[temp.length-2] + temp[temp.length-3] + temp[temp.length-4] + temp[temp.length-5];
    if (sumTop5 == 0) {
      sumTop5 = 1;
    }
    for (int i = 0; i < 5; i++) {
       top5scale[i] = ((float)temp[temp.length-(i+1)])/sumTop5;
    }
    totalSum = 0;
    for (int i = 1; i < 51; i++) {
      totalSum += temp[temp.length - i];
    }
    if (totalSum == 0) {
      totalSum = 1;
    }
}

  public int[] sort(int[] array) {
    int[] returnArray = new int[array.length];
    for (int f = 0; f < array.length; f++) {
      returnArray[f] = array[f];
    }
    boolean sort = false;
    while (!sort) {
      sort = true;
      for (int i = 0; i < returnArray.length - 1; i++) {
        if (!(returnArray[i+1] >= returnArray[i])) {
          int tempHolder = returnArray[i];
          returnArray[i] = returnArray[i+1];
          returnArray[i+1] = tempHolder;
          sort = false;
        }
      }
    }
    return returnArray;
  }
  
  public int search(int[] nums, int value) {
    int location = -1;
    for (int i = 0; i < nums.length; i++) {
      if (nums[i] == value) {
        location = i;
      }
    }
    return location;
  }
}
public class LocationDatum {

  @SerializedName("city")
    @Expose
    private String city;
  @SerializedName("address")
    @Expose
    private String address;
  @SerializedName("Monday")
    @Expose
    private String mon;
  @SerializedName("Tuesday")
    @Expose
    private String tue;
  @SerializedName("Wednesday")
    @Expose
    private String wed;
  @SerializedName("Thursday")
    @Expose
    private String thu;
  @SerializedName("Friday")
    @Expose
    private String fri;
  @SerializedName("Saturday")
    @Expose
    private String sat;
  @SerializedName("Sunday")
    @Expose
    private String sun;

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }
  
  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }
  
  public String getMonday() {
    return mon;
  }

  public void setMonday(String mon) {
    this.mon = mon;
  }
  
  public String getTuesday() {
    return tue;
  }

  public void setTuesday(String tue) {
    this.tue = tue;
  }
  
  public String getWednesday() {
    return wed;
  }

  public void setWednesday(String wed) {
    this.wed = wed;
  }
  
  public String getThursday() {
    return thu;
  }

  public void setThursday(String thu) {
    this.thu = thu;
  }
  
  public String getFriday() {
    return fri;
  }

  public void setFriday(String fri) {
    this.fri = fri;
  }
  
  public String getSaturday() {
    return sat;
  }

  public void setSaturday(String sat) {
    this.sat = sat;
  }
  
  public String getSunday() {
    return sun;
  }

  public void setSunday(String sun) {
    this.sun = sun;
  }
}



Button buy1;
Button buy2;
Button buy3;
final String AMAZON = "https://www.amazon.com/s?k=";

Button graph1;
Button graph2;
int graphType = 0;

MainDisplay display = new MainDisplay(); 
SiteDatum siteData;

Button posIncreaseButton = new Button("Positive Increase", 675, 40, 130, 30);
Button deathIncreaseButton = new Button("Death Increase", 675, 80, 130, 30);
Button hospitalizedButton = new Button("Hospitalized", 675, 120, 130, 30);
Button totalRecoveredButton = new Button("Total Recovered", 675, 160, 130, 30);
Button nextPage = new Button("->", 750, 425, 60, 30);
Button previousPage = new Button("<-", 685, 425, 60, 30);
int currentPage = 1;
int value = 0;
int savedX = 100;
int formula = 0;
boolean mouseDragged;
final int WIDTH = 1100;
NewsDatum newsInfo;
Map map = new Map();
String[] states = {"AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", 
  "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", 
  "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", 
  "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", 
  "VA", "WA", "WV", "WI", "WY"};
Timeline timeline = new Timeline(states);
boolean hasGottenData = false;
boolean [] buttons = {false, false, false, false};

public void settings() {
  size(1100, 700);
}

public void setup() {
  fill(0, 0, 0);
  textAlign(0);
  String[] fontList = PFont.list();
  PFont font = createFont(fontList[168], 32);
  textFont(font);
  textSize(24);
  String fetchText = "Please wait ... Process may take up to 15 seconds";
  text(fetchText, 300, 350);
}

public void draw() {
  if (hasGottenData) {
    updateGraphics();
  } else {
    updateData();
    hasGottenData = true;
  }
  fill(0);
  if (currentPage == 1) {
    rect(100, 450, timeline.getnumDays() * 2, 1);
  }
  if (!mouseDragged  && savedX == 100 && currentPage == 1) {
    rect(timeline.getnumDays() * 2 + 100, 445, 3, 10);
  } else if (currentPage == 1) {
    rect(savedX, 445, 3, 10);
  }
  if (currentPage == 1) {
    textSize(15);
    String str = (timeline.getDate((formula))).toString();
    text("Date: " + str.charAt(4) + str.charAt(5) + "/" + str.charAt(6) +str.charAt(7) + "/" + str.charAt(0) + str.charAt(1) + str.charAt(2) + str.charAt(3), 600, 350);
  }
}
public void updateData() {
  //map.checkSavedData();
  timeline.pullAllStatesAllDates();
  newsInfo = display.getCurrentNews();
  posIncreaseButton = new Button("Positive Increase", 675, 40, 130, 30);
  deathIncreaseButton = new Button("Death Increase", 675, 80, 130, 30);
  hospitalizedButton = new Button("Hospitalized", 675, 120, 130, 30);
  totalRecoveredButton = new Button("Total Recovered", 675, 160, 130, 30);
  buy1 = new Button("Buy Masks", 675, 40, 130, 30);
  buy2 = new Button("Buy Disinfectant", 675, 80, 130, 30);
  buy3 = new Button("Buy Custom", 675, 120, 130, 30);
  graph1 = new Button("Total", 302, 478, 60, 30);
  graph2 = new Button("Top 5", 453, 477, 60, 30);
}

public void updateGraphics() {
  background(0xffD6D6D6);
  display.grid();
  display.showNews();
  display.headers();
  display.baseText();
  noStroke();
  if (buttons[0]) {
    fill(255, 0, 0);
    int[] positiveIncreases = map.positiveIncreaseMap(timeline.getData(timeline.getDate(formula)));
    display.graph(positiveIncreases, 0, graphType);
  } else if (buttons[1]) {
    fill(0, 0, 255);
    int[] deathIncreases = map.deathIncreaseMap(timeline.getData(timeline.getDate(formula)));
    display.graph(deathIncreases, 1, graphType);
  } else if (buttons[2]) {
    fill(0, 255, 0);
    int[] hospitalized = map.hospitalizedMap(timeline.getData(timeline.getDate(formula)));
    display.graph(hospitalized, 2, graphType);
  } else if (buttons[3]) {
    fill(255, 255, 0);
    int[] recovered = map.recoveredMap(timeline.getData(timeline.getDate(formula)));
    display.graph(recovered, 3, graphType);
  } else {
    textSize(16);
    fill(0, 0, 0);
    text("Select an option from the map pane to view a graph.", 240, 600);
  }
  graph1.display(232, 232, 232, 14.5f);
  graph2.display(232, 232, 232, 14.5f);

  if (currentPage == 1) {
    textSize(25);
    fill(179, 0, 0);
    text("Map", 380, 35);
    //don't forget to reset the color and textSize
    nextPage.display(300, 300, 300, 14.5f);
    previousPage.display(150, 150, 150, 14.5f);
    display.usMap();
    posIncreaseButton.display(232, 232, 232, 14.5f);
    deathIncreaseButton.display(232, 232, 232, 14.5f);
    hospitalizedButton.display(232, 232, 232, 14.5f);
    totalRecoveredButton.display(232, 232, 232, 14.5f);
    if (buttons[0]) {
      int[] positiveIncreases = map.positiveIncreaseMap(timeline.getData(timeline.getDate(formula)));
      posIncreaseButton.display(255, 0, 0, 14.5f);
      display.circles(positiveIncreases, 255, 0, 0);
    } else if (buttons[1]) {
      //int[] deathIncreases = map.deathIncreaseMap();
      int[] deathIncreases = map.deathIncreaseMap(timeline.getData(timeline.getDate((formula))));
      deathIncreaseButton.display(0, 0, 255, 14.5f);
      display.circles(deathIncreases, 0, 0, 255);
    } else if (buttons[2]) {
      int[] hospitalized = map.hospitalizedMap(timeline.getData(timeline.getDate((formula))));
      hospitalizedButton.display(0, 255, 0, 14.5f);
      display.circles(hospitalized, 0, 255, 0);
    } else if (buttons[3]) {
      int[] recovered = map.recoveredMap(timeline.getData(timeline.getDate((formula))));
      totalRecoveredButton.display(255, 255, 0, 14.5f);
      display.circles(recovered, 255, 255, 0);
    } else {
      textSize(16);
      fill(0, 0, 0);
      text("Select an option from the map pane to view a graph.", 240, 600);
    }
  }

  if (currentPage == 2) {
    nextPage.display(150, 150, 150, 14.5f);
    previousPage.display(300, 300, 300, 14.5f);
    display.testingLocations();

    buy1.display(232, 232, 232, 14.5f);
    buy2.display(232, 232, 232, 14.5f);
    buy3.display(232, 232, 232, 14.5f);
  }
}


public void mousePressed() {
  if (410 < mouseY && 480 > mouseY && 100 < mouseX && mouseX < 100 + timeline.getnumDays() * 2) {
    savedX = mouseX;
    formula = Math.abs(((savedX - 100)/2) - (timeline.getnumDays()-1));
    rect(mouseX, 445, 3, 10);
    mouseDragged = true;
  } else {
    mouseDragged = false;
  }
  if (mouseX >= WIDTH*3/4 && mouseX <= WIDTH && mouseY >= 51 && mouseY <= 134) {
    try {
      link(newsInfo.getArticles().get(0).getURL());
    }
    catch(Exception e) {
    }
  } else if (mouseX >= WIDTH*3/4 && mouseX <= WIDTH && mouseY > 134 && mouseY <= 217) {
    try {
      link(newsInfo.getArticles().get(1).getURL());
    }
    catch(Exception e) {
    }
  } else if (mouseX >= WIDTH*3/4 && mouseX <= WIDTH && mouseY > 217 && mouseY <= 300) {
    try {
      link(newsInfo.getArticles().get(2).getURL());
    }
    catch(Exception e) {
    }
  }
  if (nextPage.mouseIsOver()) {
    if (currentPage!=2) {
      currentPage++;
    }
  }
  if (previousPage.mouseIsOver()) {
    if (currentPage!=1) {
      currentPage--;
    }
  }

  if (mouseX >= WIDTH*3/4 && mouseX <= WIDTH && mouseY > 300 && mouseY <= 400) {
    link("https://www.cdc.gov/coronavirus/2019-ncov/prevent-getting-sick/prevention.html");
  }


  if (currentPage == 1) {
    if (posIncreaseButton.mouseIsOver()) {
      buttons[0] = true;
      buttons[1] = false;
      buttons[2] = false;
      buttons[3] = false;
    } else if (deathIncreaseButton.mouseIsOver()) {
      buttons[0] = false;
      buttons[1] = true;
      buttons[2] = false;
      buttons[3] = false;
    } else if (hospitalizedButton.mouseIsOver()) {
      buttons[0] = false;
      buttons[1] = false;
      buttons[2] = true;
      buttons[3] = false;
    } else if (totalRecoveredButton.mouseIsOver()) {
      buttons[0] = false;
      buttons[1] = false;
      buttons[2] = false;
      buttons[3] = true;
    }
  }

  if (currentPage == 2) {
    if (buy1.mouseIsOver()) {
      link(AMAZON + "masks");
    } else if (buy2.mouseIsOver()) {
      link(AMAZON + "disinfectant");
    } else if (buy3.mouseIsOver()) {
      String item = showInputDialog(null, "Please enter the item you want to buy: ", "Search for Supplies", INFORMATION_MESSAGE);
      if (item != null && !item.replaceAll(" ", "").equals("")) {
        link(AMAZON + item.replace(' ', '+'));
      }
    }
  }

  if (graph1.mouseIsOver()) {
    graphType = 0;
    graph1.display(300, 300, 300, 14.5f);
    graph2.display(232, 232, 232, 14.5f);
  } else if (graph2.mouseIsOver()) {
    graphType = 1;
    graph2.display(300, 300, 300, 14.5f);
    graph1.display(232, 232, 232, 14.5f);
  }

  if (display.feverButton.mouseIsOver()) {
    link("https://www.healthline.com/health/fever");
  } else if (display.coughButton.mouseIsOver()) {
    link("https://www.healthline.com/symptom/cough");
  } else if (display.fatigueButton.mouseIsOver()) {
    link("https://www.healthline.com/health/fatigue");
  } else if (display.breathingButton.mouseIsOver()) {
    link("https://www.healthline.com/health/breathing-difficulties");
  } else if (display.headacheButton.mouseIsOver()) {
    link("https://www.healthline.com/health/headache");
  } else if (display.lossOfTasteButton.mouseIsOver()) {
    link("https://www.healthline.com/health/taste-impaired");
  } else if (display.soreThroatButton.mouseIsOver()) {
    link("https://www.healthline.com/health/sore-throat");
  } else if (display.congestionButton.mouseIsOver()) {
    link("https://www.healthline.com/health/nasal-congestion");
  } else if (display.runnyNoseButton.mouseIsOver()) {
    link("https://www.healthline.com/health/runny-nose-causes");
  } else if (display.nauseaButton.mouseIsOver()) {
    link("https://www.healthline.com/health/nausea");
  } else if (display.vomitingButton.mouseIsOver()) {
    link("https://www.healthline.com/health/vomiting");
  } else if (display.diarrheaButton.mouseIsOver()) {
    link("https://www.healthline.com/health/diarrhea");
  }

  loadTestingLocations();
  if (display.stAnthonyButton.mouseIsOver()) {
    String monday = siteData.getStAnthony().getMonday();
    String tuesday = siteData.getStAnthony().getTuesday();
    String wednesday = siteData.getStAnthony().getWednesday();
    String thursday = siteData.getStAnthony().getThursday();
    String friday = siteData.getStAnthony().getFriday();
    String saturday = siteData.getStAnthony().getSaturday();
    String sunday = siteData.getStAnthony().getSunday();
    showMessageDialog(null, "Sunday: " + sunday + "\nMonday: " + monday + "\nTuesday: " + tuesday + "\nWednesday: " + wednesday + "\nThursday: " + thursday + "\nFriday: " + friday + "\nSaturday: " + saturday, "Available Times", INFORMATION_MESSAGE);
  } else if (display.tubmanChavezButton.mouseIsOver()) {
    String monday = siteData.getTubmanChavez().getMonday();
    String tuesday = siteData.getTubmanChavez().getTuesday();
    String wednesday = siteData.getTubmanChavez().getWednesday();
    String thursday = siteData.getTubmanChavez().getThursday();
    String friday = siteData.getTubmanChavez().getFriday();
    String saturday = siteData.getTubmanChavez().getSaturday();
    String sunday = siteData.getTubmanChavez().getSunday();
    showMessageDialog(null, "Sunday: " + sunday + "\nMonday: " + monday + "\nTuesday: " + tuesday + "\nWednesday: " + wednesday + "\nThursday: " + thursday + "\nFriday: " + friday + "\nSaturday: " + saturday, "Available Times", INFORMATION_MESSAGE);
  } else if (display.aquaticaButton.mouseIsOver()) {
    String monday = siteData.getAquatica().getMonday();
    String tuesday = siteData.getAquatica().getTuesday();
    String wednesday = siteData.getAquatica().getWednesday();
    String thursday = siteData.getAquatica().getThursday();
    String friday = siteData.getAquatica().getFriday();
    String saturday = siteData.getAquatica().getSaturday();
    String sunday = siteData.getAquatica().getSunday();
    showMessageDialog(null, "Sunday: " + sunday + "\nMonday: " + monday + "\nTuesday: " + tuesday + "\nWednesday: " + wednesday + "\nThursday: " + thursday + "\nFriday: " + friday + "\nSaturday: " + saturday, "Available Times", INFORMATION_MESSAGE);
  } else if (display.sycuanButton.mouseIsOver()) {
    String monday = siteData.getSycuan().getMonday();
    String tuesday = siteData.getSycuan().getTuesday();
    String wednesday = siteData.getSycuan().getWednesday();
    String thursday = siteData.getSycuan().getThursday();
    String friday = siteData.getSycuan().getFriday();
    String saturday = siteData.getSycuan().getSaturday();
    String sunday = siteData.getSycuan().getSunday();
    showMessageDialog(null, "Sunday: " + sunday + "\nMonday: " + monday + "\nTuesday: " + tuesday + "\nWednesday: " + wednesday + "\nThursday: " + thursday + "\nFriday: " + friday + "\nSaturday: " + saturday, "Available Times", INFORMATION_MESSAGE);
  } else if (display.marVistaButton.mouseIsOver()) {
    String monday = siteData.getMarVista().getMonday();
    String tuesday = siteData.getMarVista().getTuesday();
    String wednesday = siteData.getMarVista().getWednesday();
    String thursday = siteData.getMarVista().getThursday();
    String friday = siteData.getMarVista().getFriday();
    String saturday = siteData.getMarVista().getSaturday();
    String sunday = siteData.getMarVista().getSunday();
    showMessageDialog(null, "Sunday: " + sunday + "\nMonday: " + monday + "\nTuesday: " + tuesday + "\nWednesday: " + wednesday + "\nThursday: " + thursday + "\nFriday: " + friday + "\nSaturday: " + saturday, "Available Times", INFORMATION_MESSAGE);
  } else if (display.northCoastalButton.mouseIsOver()) {
    String monday = siteData.getNorthCoastal().getMonday();
    String tuesday = siteData.getNorthCoastal().getTuesday();
    String wednesday = siteData.getNorthCoastal().getWednesday();
    String thursday = siteData.getNorthCoastal().getThursday();
    String friday = siteData.getNorthCoastal().getFriday();
    String saturday = siteData.getNorthCoastal().getSaturday();
    String sunday = siteData.getNorthCoastal().getSunday();
    showMessageDialog(null, "Sunday: " + sunday + "\nMonday: " + monday + "\nTuesday: " + tuesday + "\nWednesday: " + wednesday + "\nThursday: " + thursday + "\nFriday: " + friday + "\nSaturday: " + saturday, "Available Times", INFORMATION_MESSAGE);
  } else if (display.lgbtButton.mouseIsOver()) {
    String monday = siteData.getLgbtCenter().getMonday();
    String tuesday = siteData.getLgbtCenter().getTuesday();
    String wednesday = siteData.getLgbtCenter().getWednesday();
    String thursday = siteData.getLgbtCenter().getThursday();
    String friday = siteData.getLgbtCenter().getFriday();
    String saturday = siteData.getLgbtCenter().getSaturday();
    String sunday = siteData.getLgbtCenter().getSunday();
    showMessageDialog(null, "Sunday: " + sunday + "\nMonday: " + monday + "\nTuesday: " + tuesday + "\nWednesday: " + wednesday + "\nThursday: " + thursday + "\nFriday: " + friday + "\nSaturday: " + saturday, "Available Times", INFORMATION_MESSAGE);
  } else if (display.euclidButton.mouseIsOver()) {
    String monday = siteData.getEuclidCenter().getMonday();
    String tuesday = siteData.getEuclidCenter().getTuesday();
    String wednesday = siteData.getEuclidCenter().getWednesday();
    String thursday = siteData.getEuclidCenter().getThursday();
    String friday = siteData.getEuclidCenter().getFriday();
    String saturday = siteData.getEuclidCenter().getSaturday();
    String sunday = siteData.getEuclidCenter().getSunday();
    showMessageDialog(null, "Sunday: " + sunday + "\nMonday: " + monday + "\nTuesday: " + tuesday + "\nWednesday: " + wednesday + "\nThursday: " + thursday + "\nFriday: " + friday + "\nSaturday: " + saturday, "Available Times", INFORMATION_MESSAGE);
  } else if (display.sdStateButton.mouseIsOver()) {
    String monday = siteData.getSdState().getMonday();
    String tuesday = siteData.getSdState().getTuesday();
    String wednesday = siteData.getSdState().getWednesday();
    String thursday = siteData.getSdState().getThursday();
    String friday = siteData.getSdState().getFriday();
    String saturday = siteData.getSdState().getSaturday();
    String sunday = siteData.getSdState().getSunday();
    showMessageDialog(null, "Sunday: " + sunday + "\nMonday: " + monday + "\nTuesday: " + tuesday + "\nWednesday: " + wednesday + "\nThursday: " + thursday + "\nFriday: " + friday + "\nSaturday: " + saturday, "Available Times", INFORMATION_MESSAGE);
  } else if (display.usdLotButton.mouseIsOver()) {
    String monday = siteData.getUsdLot().getMonday();
    String tuesday = siteData.getUsdLot().getTuesday();
    String wednesday = siteData.getUsdLot().getWednesday();
    String thursday = siteData.getUsdLot().getThursday();
    String friday = siteData.getUsdLot().getFriday();
    String saturday = siteData.getUsdLot().getSaturday();
    String sunday = siteData.getUsdLot().getSunday();
    showMessageDialog(null, "Sunday: " + sunday + "\nMonday: " + monday + "\nTuesday: " + tuesday + "\nWednesday: " + wednesday + "\nThursday: " + thursday + "\nFriday: " + friday + "\nSaturday: " + saturday, "Available Times", INFORMATION_MESSAGE);
  } else if (display.searsButton.mouseIsOver()) {
    String monday = siteData.getSears().getMonday();
    String tuesday = siteData.getSears().getTuesday();
    String wednesday = siteData.getSears().getWednesday();
    String thursday = siteData.getSears().getThursday();
    String friday = siteData.getSears().getFriday();
    String saturday = siteData.getSears().getSaturday();
    String sunday = siteData.getSears().getSunday();
    showMessageDialog(null, "Sunday: " + sunday + "\nMonday: " + monday + "\nTuesday: " + tuesday + "\nWednesday: " + wednesday + "\nThursday: " + thursday + "\nFriday: " + friday + "\nSaturday: " + saturday, "Available Times", INFORMATION_MESSAGE);
  } else if (display.assessorRecorderButton.mouseIsOver()) {
    String monday = siteData.getAssessorRecorder().getMonday();
    String tuesday = siteData.getAssessorRecorder().getTuesday();
    String wednesday = siteData.getAssessorRecorder().getWednesday();
    String thursday = siteData.getAssessorRecorder().getThursday();
    String friday = siteData.getAssessorRecorder().getFriday();
    String saturday = siteData.getAssessorRecorder().getSaturday();
    String sunday = siteData.getAssessorRecorder().getSunday();
    showMessageDialog(null, "Sunday: " + sunday + "\nMonday: " + monday + "\nTuesday: " + tuesday + "\nWednesday: " + wednesday + "\nThursday: " + thursday + "\nFriday: " + friday + "\nSaturday: " + saturday, "Available Times", INFORMATION_MESSAGE);
  } else if (display.escondidoTheaterButton.mouseIsOver()) {
    String monday = siteData.getArtsCenter().getMonday();
    String tuesday = siteData.getArtsCenter().getTuesday();
    String wednesday = siteData.getArtsCenter().getWednesday();
    String thursday = siteData.getArtsCenter().getThursday();
    String friday = siteData.getArtsCenter().getFriday();
    String saturday = siteData.getArtsCenter().getSaturday();
    String sunday = siteData.getArtsCenter().getSunday();
    showMessageDialog(null, "Sunday: " + sunday + "\nMonday: " + monday + "\nTuesday: " + tuesday + "\nWednesday: " + wednesday + "\nThursday: " + thursday + "\nFriday: " + friday + "\nSaturday: " + saturday, "Available Times", INFORMATION_MESSAGE);
  } else if (display.kimballButton.mouseIsOver()) {
    String monday = siteData.getKimballCenter().getMonday();
    String tuesday = siteData.getKimballCenter().getTuesday();
    String wednesday = siteData.getKimballCenter().getWednesday();
    String thursday = siteData.getKimballCenter().getThursday();
    String friday = siteData.getKimballCenter().getFriday();
    String saturday = siteData.getKimballCenter().getSaturday();
    String sunday = siteData.getKimballCenter().getSunday();
    showMessageDialog(null, "Sunday: " + sunday + "\nMonday: " + monday + "\nTuesday: " + tuesday + "\nWednesday: " + wednesday + "\nThursday: " + thursday + "\nFriday: " + friday + "\nSaturday: " + saturday, "Available Times", INFORMATION_MESSAGE);
  } else if (display.sanYsidroButton.mouseIsOver()) {
    String monday = siteData.getSanYsidro().getMonday();
    String tuesday = siteData.getSanYsidro().getTuesday();
    String wednesday = siteData.getSanYsidro().getWednesday();
    String thursday = siteData.getSanYsidro().getThursday();
    String friday = siteData.getSanYsidro().getFriday();
    String saturday = siteData.getSanYsidro().getSaturday();
    String sunday = siteData.getSanYsidro().getSunday();
    showMessageDialog(null, "Sunday: " + sunday + "\nMonday: " + monday + "\nTuesday: " + tuesday + "\nWednesday: " + wednesday + "\nThursday: " + thursday + "\nFriday: " + friday + "\nSaturday: " + saturday, "Available Times", INFORMATION_MESSAGE);
  } else if (display.miraMesaButton.mouseIsOver()) {
    String monday = siteData.getMiraMesa().getMonday();
    String tuesday = siteData.getMiraMesa().getTuesday();
    String wednesday = siteData.getMiraMesa().getWednesday();
    String thursday = siteData.getMiraMesa().getThursday();
    String friday = siteData.getMiraMesa().getFriday();
    String saturday = siteData.getMiraMesa().getSaturday();
    String sunday = siteData.getMiraMesa().getSunday();
    showMessageDialog(null, "Sunday: " + sunday + "\nMonday: " + monday + "\nTuesday: " + tuesday + "\nWednesday: " + wednesday + "\nThursday: " + thursday + "\nFriday: " + friday + "\nSaturday: " + saturday, "Available Times", INFORMATION_MESSAGE);
  }
}

public void loadTestingLocations() {
  siteData = map.gson.fromJson(arrayToString(loadStrings("testingData.txt")), SiteDatum.class);
}

public String arrayToString(String[] array) {
  String finalString = "";
  for (String s : array) {
    finalString += s;
  }
  return finalString;
}

public void mouseDragged() {
  if ( 410 < mouseY && 480 > mouseY && 100 < mouseX && mouseX < 100 + timeline.getnumDays() * 2 ) {
    formula = Math.abs(((savedX - 100)/2) - (timeline.getnumDays() - 1) );
    rect(mouseX, 445, 3, 10);
    savedX = mouseX;
    mouseDragged = true;
  } else {
    mouseDragged = false;
  }
}









public class Map { 
  JsonObject[] jsonData = new JsonObject[50];
  Datum[] data = new Datum[50];
  final Gson gson = new Gson();
  String[] lines = new String[50];
  int[] positiveIncreases = new int[50];
  int[] deathIncreases = new int[50];
  int[] hospitalized = new int[50];
  int[] recovered = new int[50];
  String[] states = {"al", "ak", "az", "ar", "ca", "co", "ct", "de", "fl", 
    "ga", "hi", "id", "il", "in", "ia", "ks", "ky", "la", "me", "md", "ma", 
    "mi", "mn", "ms", "mo", "mt", "ne", "nv", "nh", "nj", "nm", "ny", "nc", 
    "nd", "oh", "ok", "or", "pa", "ri", "sc", "sd", "tn", "tx", "ut", "vt", 
    "va", "wa", "wv", "wi", "wy"};
  public void pullAllStates() {
    //text("Retrieving data...", 530, 350);
    String[] stringJsonData = new String[50];
    for (int i = 0; i < states.length; i++) {
      JsonObject userJSON = pullState(states[i]);

      Datum request = gson.fromJson(userJSON.toString(), Datum.class);
      data[i] = request;
      jsonData[i] = userJSON;
      stringJsonData[i] = jsonData[i].toString();
    }
    println(stringJsonData[0]);
    saveStrings("data1.txt", stringJsonData);
    lines = loadStrings("data1.txt");
  }

  public JsonObject pullState(String state) {
    try {
      String requestURL;
      requestURL = "https://covidtracking.com/api/v1/states/" + state + "/current.json";
         
      URL url = new URL(requestURL);
      HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
      con.setRequestMethod("GET");
      JsonReader repoReader = Json.createReader(con.getInputStream());
      JsonObject userJSON = ((JsonObject) repoReader.read());
      con.disconnect();

      return userJSON;
    } 
    catch (MalformedURLException e) {
      e.printStackTrace();
    } 
    catch (ProtocolException e) {
      e.printStackTrace();
    } 
    catch (IOException e) {
      e.printStackTrace();
    }
    return null;
  }

  public String loadState() {
    lines = loadStrings("data.txt");

    return lines[0];
  }
  public void checkSavedData() {
    Datum savedData;
    Datum apiData;
    String savedJSON;
    JsonObject apiJSON;

    apiJSON = pullState("al");
    savedJSON = loadState();

    apiData = gson.fromJson(apiJSON.toString(), Datum.class);
    savedData = gson.fromJson(savedJSON.toString(), Datum.class);
    try{
      if (!apiData.getDate().equals(savedData.getDate())) {
        pullAllStates();
      }
    } catch(NullPointerException e) {
       pullAllStates();
    }
  } 

  public int[] positiveIncreaseMap(String[] inputLines) {
    boolean indexAtComma = false;
    int commaIndex = 0;
    int positiveIndex = 0;
    for (String c : inputLines) {
      if(c == null)
      {
        positiveIncreases[positiveIndex] = 0;
        positiveIndex++;
        continue;
      }
      for (int i = 0; i < c.length(); i++) {
        if (i <= c.length()-16) {
          if (c.substring(i, i+16).equals("positiveIncrease")) {
            commaIndex = i+17;
            while (!indexAtComma) {
              if (c.charAt(commaIndex) == ',') {
                break;
              }
              commaIndex++;
            }
            positiveIncreases[positiveIndex] = Integer.parseInt(c.substring(i+18, commaIndex));
            positiveIndex++;
          }
        }
      }

    }
    return positiveIncreases;
  }


  public int[] deathIncreaseMap(String[] inputLines) {
    boolean indexAtComma = false;
    int commaIndex = 0;
    int positiveIndex = 0;

    for (String c : inputLines) {
        if(c == null)
      {
        deathIncreases[positiveIndex] = 0;
        positiveIndex++;
        continue;
      }
      for (int i = 0; i < c.length(); i++) {
        if (i <= c.length()-13) {
          if (c.substring(i, i+13).equals("deathIncrease")) {
            commaIndex = i+14;
            while (!indexAtComma) {
              if (c.charAt(commaIndex) == ',') {
                break;
              }
              commaIndex++;
            }
            deathIncreases[positiveIndex] = (Integer.parseInt(c.substring(i+15, commaIndex))) * 10;
            positiveIndex++;
          }
        }
      }
    }

    return deathIncreases;
  }

  public int[] hospitalizedMap(String[] inputLines) {
    boolean indexAtComma = false;
    int commaIndex = 0;
    int positiveIndex = 0;

    for (String c : inputLines) {
        if(c == null)
      {
        hospitalized[positiveIndex] = 0;
        positiveIndex++;
        continue;
      }
      for (int i = 0; i < c.length(); i++) {
        if (i <= c.length()-21) {
          if (c.substring(i, i+21).equals("hospitalizedCurrently")) {
            commaIndex = i+22;
            while (!indexAtComma) {
              if (c.charAt(commaIndex) == ',') {
                break;
              }
              commaIndex++;
            }
            if (!c.substring(i+23, commaIndex).equals("null")) {
              hospitalized[positiveIndex] = Integer.parseInt(c.substring(i+23, commaIndex));
            } else {
              hospitalized[positiveIndex] = 0;
            }
            positiveIndex++;
          }
        }
      }
    }

    return hospitalized;
  }

  public int[] recoveredMap(String[] inputLines) {
    boolean indexAtComma = false;
    int commaIndex = 0;
    int positiveIndex = 0;

    for (String c : inputLines) {
       if(c == null)
      {
        recovered[positiveIndex] = 0;
        positiveIndex++;
        continue;
      }
      for (int i = 0; i < c.length(); i++) {
        if (i <= c.length()-9) {
          if (c.substring(i, i+9).equals("recovered")) {
            commaIndex = i+10;
            while (!indexAtComma) {
              if (c.charAt(commaIndex) == ',') {
                break;
              }
              commaIndex++;
            }
            if (!c.substring(i+11, commaIndex).equals("null")) {
              recovered[positiveIndex] = (Integer.parseInt(c.substring(i+11, commaIndex)))/25;
            } else {
              recovered[positiveIndex] = 0;
            }
            positiveIndex++;
          }
        }
      }
    }
    return recovered;
  }
  
  public String[] getData()
  {
    return lines;
  }
  
  public String[] getStates()
  {
    return states;
  }
}





public class MapRequest {

  @SerializedName("data")
    @Expose
    private Datum data = null;

  public Datum getData() {
    return data;
  }

  public void setData(Datum data) {
    this.data = data;
  }
}











public class News {
  public NewsDatum fetchTopNews() {
    URL url;
    final Gson gson = new Gson();
    try {
      String a="http://newsapi.org/v2/top-headlines?q=Covid-19&country=us&sortBy=popularity&apiKey=02080297f046477fb6ca1181fab28e51";
      url = new URL(a);
      URLConnection conn = url.openConnection();

      BufferedReader br = new BufferedReader(
        new InputStreamReader(conn.getInputStream()));
      String siteContents = "";
      String inputLine = br.readLine();
      while (inputLine != null) {
        siteContents += inputLine;
        inputLine = br.readLine();
      }
      br.close();
      siteContents = siteContents.trim();
      NewsDatum request = gson.fromJson(siteContents, NewsDatum.class);
      return request;
    } 
    catch (MalformedURLException e) {
      e.printStackTrace();
    } 
    catch (IOException e) {
      e.printStackTrace();
    }
    return null;
  }
}



public class NewsDatum{
  @SerializedName("totalResults")
    @Expose
    private Integer totalResults;
  
  @SerializedName("articles")
    @Expose
    private List <ArticleDatum> articles;
    
  public Integer getTotalResults() {
    return totalResults;
  }

  public void setTotalResults(Integer totalResults) {
    this.totalResults = totalResults;
  }
  
  public List<ArticleDatum> getArticles() {
    return articles;
  }

  public void setArticles(List<ArticleDatum> articles) {
    this.articles = articles;
  }
}
public class SiteDatum {
  @SerializedName("St. Anthony's of Padua Parking Lot")
    @Expose
    private LocationDatum stAnthony;

  @SerializedName("Tubman-Chavez Community Center")
    @Expose
    private LocationDatum tubmanChavez;

  @SerializedName("Aquatica San Diego")
    @Expose
    private LocationDatum aquatica;

  @SerializedName("Sycuan Market")
    @Expose
    private LocationDatum sycuan;

  @SerializedName("Mar Vista High School")
    @Expose
    private LocationDatum marVista;

  @SerializedName("North Coastal Live Well Health Center")
    @Expose
    private LocationDatum northCoastal;

  @SerializedName("The San Diego LGBT Community Center")
    @Expose
    private LocationDatum lgbtCenter;

  @SerializedName("San Diego State University Parking Lot 17B")
    @Expose
    private LocationDatum sdState;

  @SerializedName("University of San Diego (USD) Parking Lot")
    @Expose
    private LocationDatum usdLot;

  @SerializedName("Old Sears Building")
    @Expose
    private LocationDatum sears;

  @SerializedName("Assessor Recorder County Clerk Building")
    @Expose
    private LocationDatum assessorRecorder;

  @SerializedName("California Center for the Arts, Escondido Center Theater")
    @Expose
    private LocationDatum artsCenter;

  @SerializedName("Kimball Senior Center")
    @Expose
    private LocationDatum kimballCenter;

  @SerializedName("San Ysidro Civic Center")
    @Expose
    private LocationDatum sanYsidro;

  @SerializedName("Mira Mesa Senior Center")
    @Expose
    private LocationDatum miraMesa;

  @SerializedName("Euclid Health Center")
    @Expose
    private LocationDatum euclidCenter;

  public LocationDatum getStAnthony() {
    return stAnthony;
  }

  public void setStAnthony(LocationDatum stAnthony) {
    this.stAnthony = stAnthony;
  }
  
  public LocationDatum getTubmanChavez() {
    return tubmanChavez;
  }

  public void setTubmanChavez(LocationDatum tubmanChavez) {
    this.tubmanChavez = tubmanChavez;
  }

  public LocationDatum getAquatica() {
    return aquatica;
  }

  public void setAquatica(LocationDatum aquatica) {
    this.aquatica = aquatica;
  }
  
  public LocationDatum getSycuan() {
    return sycuan;
  }

  public void setSycuan(LocationDatum sycuan) {
    this.sycuan = sycuan;
  }
  
  public LocationDatum getMarVista() {
    return marVista;
  }

  public void setMarVista(LocationDatum marVista) {
    this.marVista = marVista;
  }
  
  public LocationDatum getNorthCoastal() {
    return northCoastal;
  }

  public void setNorthCoastal(LocationDatum northCoastal) {
    this.northCoastal = northCoastal;
  }
  
  public LocationDatum getLgbtCenter() {
    return lgbtCenter;
  }

  public void setLgbtCenter(LocationDatum lgbtCenter) {
    this.lgbtCenter = lgbtCenter;
  }
  
  public LocationDatum getSdState() {
    return sdState;
  }

  public void setSdState(LocationDatum sdState) {
    this.sdState = sdState;
  }
  
  public LocationDatum getUsdLot() {
    return usdLot;
  }

  public void setUsdLot(LocationDatum usdLot) {
    this.usdLot = usdLot;
  }
  
  public LocationDatum getSears() {
    return sears;
  }

  public void setSears(LocationDatum sears) {
    this.sears = sears;
  }
  
  public LocationDatum getAssessorRecorder() {
    return sears;
  }

  public void setAssessorRecorder(LocationDatum assessorRecorder) {
    this.assessorRecorder = assessorRecorder;
  }
  
  public LocationDatum getArtsCenter() {
    return sears;
  }

  public void setArtsCenter(LocationDatum artsCenter) {
    this.artsCenter = artsCenter;
  }
  
  public LocationDatum getKimballCenter() {
    return sears;
  }

  public void setKimballCenter(LocationDatum kimballCenter) {
    this.kimballCenter = kimballCenter;
  }
  
  public LocationDatum getSanYsidro() {
    return sears;
  }

  public void setSanYsidro(LocationDatum sanYsidro) {
    this.sanYsidro = sanYsidro;
  }
  
  public LocationDatum getMiraMesa() {
    return sears;
  }

  public void setMiraMesa(LocationDatum miraMesa) {
    this.miraMesa = miraMesa;
  }
  
  public LocationDatum getEuclidCenter() {
    return sears;
  }

  public void setEuclidCenter(LocationDatum euclidCenter) {
    this.euclidCenter = euclidCenter;
  }
}












public class Timeline{
    final Gson gson = new Gson();
    
    HashMap data = new HashMap<Integer, String[]>();
    HashMap stateIndex = new HashMap<String, Integer>();
    int numDays; 
    Integer[] dateArray = new Integer[365];
 
    
    Timeline(String[] states) {
      for(int i = 0; i < states.length; i++) {
        stateIndex.put(states[i], i);
      }
    }
    

  public void pullAllStatesAllDates(){
     JsonArray userJSON = pullData();
     
     int index = 0;
       
     while(true) {
       JsonObject tmp = userJSON.getJsonObject(index);
       Integer date           = gson.fromJson(tmp.toString(), Datum.class).getDate();
       dateArray[numDays] = date;
       
       String[] dateData = new String[50];
       while(true) {
         JsonObject obj = userJSON.getJsonObject(index);
         Integer nextdate  = gson.fromJson(obj.toString(), Datum.class).getDate();
         String  state = gson.fromJson(obj.toString(), Datum.class).getState();
         
         if(!nextdate.equals(date))
           break;
         
         if(stateIndex.get(state) == null) {
           index++;
           if(index == userJSON.size()) {
             break;
           }
           continue;
         }
         else {
           dateData[(int)stateIndex.get(state)] = obj.toString();
           index++;
           if(index == userJSON.size()) {
             break;
           }
         }
       }
       data.put(date, dateData);
       numDays++;
       
       if(index == userJSON.size()) {
         break;
       }
     }
  }
     
  public JsonArray pullData() {
    try {
      String requestURL;
          
          requestURL = "https://api.covidtracking.com/v1/states/daily.json";
      
      URL url = new URL(requestURL);
      HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
      con.setRequestMethod("GET");
      JsonReader repoReader = Json.createReader(con.getInputStream());
      JsonArray userJSON = ((JsonArray) repoReader.readArray());
      con.disconnect();

      return userJSON;
      }
    catch (MalformedURLException e) {
      e.printStackTrace();
    } 
    catch (ProtocolException e) {
      e.printStackTrace();
    } 
    catch (IOException e) {
      e.printStackTrace();
    }
    return null;
  }
  
  public String[] getData(int date) {
    return ((String[])data.get(date));
  }
  
  public Integer getDate(int index) {
    return dateArray[index];
  }
  public int getnumDays() {
    return numDays;
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Display" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
